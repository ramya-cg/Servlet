package com.demo.exception;

public class Exception2 {

	public static final String ERROR1 = "Enter valid FirstName";
	public static final String ERROR2 = "Enter valid second name";
	public static final String ERROR3 = "Enter address";
	public static final String ERROR4 = "Mobile number must be 10 digits starting with 7-9";
	public static final String ERROR5 = "Enter the PAN Number (eg WHGC15472X";
	public static final String ERROR6 = "Enter 10 digit account number";
	public static final String ERROR7 = "Enter 10 digit credit card number";
	public static final String ERROR8 ="Enter interest greater tham 100";
	public static final String ERROR9 = "loan amount must be greater than 10000";
	public static final String ERROR10 = "Time must be greater than 28yrs";

}
